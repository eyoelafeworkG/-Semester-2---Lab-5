// This is a a template program for you to submit lab assignments in lab 5
// Lab Title: Average Temperature 
// Student Details
/// Name: Place your name here
/// ID: Place your ID here

#include <iostream>
#include <iomanip>

using namespace std;

/// State your typedef statement here

/// Write your function declarations here

/// End of your function declarations

int main()
{

	///  1. Initialize all elements of the array to zero
	///  2. Prompt the user to input the total number of temperatures
	///  3. Accept the temperature count from the keyboard
	///  4. If this input is greater than the total size of allowed temperatures (50 in this case) prompt error and stop
	///  5. Else, iteratively accept the temperatures and store them to the array
	///  7. Call the function that returns maximum temperature and save the returned value
	///  8. Call the function that returns maximum temperature and save the returned value
	///  9. Calculate the average temperature
	/// 10. Display the minimum, maximum and average temperatures
	
	return 0;
}

/// Write definition of the function that returns minimum temperature here


/// End of your function definition 


/// Write definition of the function that returns maximum temperature here


/// End of your function definition 