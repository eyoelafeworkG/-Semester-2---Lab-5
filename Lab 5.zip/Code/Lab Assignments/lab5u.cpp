// This is a a template program for you to submit lab assignments in lab 5
// Lab Title: Cucumber Array

//  Student Details
/// Name: Place your name here
/// ID: Place your ID here

#include <iostream>
#include <iomanip>

using namespace std;

// declaration of isCucumber function
int isCucumber(int a[], int len)
// End of function declaration

int main()
{

	cout << "Output of isCucumber function:" <<endl;
	
	/// Write statements that call your function to test your solution
	
	return 0;
}

// Definition isCucumber function
int isCucumber(int a[ ], int len)
{
	int returnValue = 1;

	/// Write your solution here
	
	return returnValue;
}
// End of function definition 