// This is a a template program for you to submit lab assignments in lab 5
// Lab Title: Number of Grades

//  Student Details
/// Name: Place your name here
/// ID: Place your ID here

#include <iostream>
#include <iomanip>

using namespace std;

/// State your typedef statement here

/// Write declarations for the function that counts the grades here

/// End of your function declaration

int main()
{

	///  1. Initialize all elements of the array to null character
	///  2. Prompt the user to input the total number of letter grades
	///  3. Accept the grade count from the keyboard
	///  4. If this input is greater than the total size of allowed grades (50 in this case) prompt error and stop
	///  5. Else, iteratively accept the grades and store them to the array
	///  7. For each grade later call the function that returns total number of that grade letters entered by the user
	///  8. Display the returned value to the screen
	
	return 0;
}

/// Write definition for the function that counts the grades here


/// End of your function definition 