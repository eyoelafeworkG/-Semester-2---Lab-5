// This is a a template program for you to submit lab assignments in lab 5
// Lab Title: Daphne Array

//  Student Details
/// Name: Place your name here
/// ID: Place your ID here

#include <iostream>
#include <iomanip>

using namespace std;

// declaration of isDaphneArray function
int isDaphneArray(int a[], int len)
// End of function declaration

int main()
{

	cout << "Output of isDaphneArray function:" <<endl;
	
	/// Write statements that call your function to test your solution
	
	return 0;
}

// Definition isDaphneArray function
int isDaphneArray(int a[ ], int len)
{
	int returnValue = 1;

	/// Write your solution here
	
	return returnValue;
}
// End of function definition 