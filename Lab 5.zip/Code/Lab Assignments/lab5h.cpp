// This is a a template program for you to submit lab assignments in lab 5
// Lab Title: Age Population Program
// Student Details
/// Name: Place your name here
/// ID: Place your ID here

#include <iostream>
#include <iomanip>

using namespace std;

/// State your typedef statement here, if any

/// Write your function declaration here, if any

int main()
{

	/// 1. Initialize all elements of the array to zero
	/// 2. Prompt the user to input an age
	/// 3. Accept the age from the keyboard(the first age to input)
	/// 4. while the input age is different from -99 
	/// 5. add one to the counter of the input age indexed by the input age -1-
	/// 6. Prompt the user to input an age
	/// 7. Accept the age from the keyboard
	/// 8. Repeat steps 4 to 7

	// Start displaying the ages frequencies 
	/// For all ages stored
	/// if this age's frequency count is greater than zero display its count
	
	return 0;
}