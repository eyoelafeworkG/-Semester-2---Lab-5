// This is a a template program for you to test the pre-lab exercises in lab 5
#include<iostream>
using namespace std;


int main()
{
	/// Insert line of code you want to test starting from here
	
	
	/// End of the code you want to test
	
	int size = _______; /// Please fill the size of array abort here
	
	for (int i = 0; i < size; i++)
	{
		cout << "a[" << i << "] = " << a[i] << endl;
	}
	
	return 0;
}

