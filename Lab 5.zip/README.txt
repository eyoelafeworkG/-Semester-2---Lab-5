Please attempt all questions in this lab (Lab 5) and submit your answers (Source code only) 
before May 28, 12:00 PM (noon) via email. The subject of your email should be: CPP LAB 5.
You should zip the source files only before sending the email. Feel Free to contact me
via email if you have any questions or need clarification on any of the questions.

Good Luck and Happy Coding 